import { useState } from 'react';

function UserForm() {
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    groupCode: '',
    email: ''
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  return (
    <div style={{ maxWidth: '400px', margin: '20px auto', fontFamily: 'sans-serif' }}>
      <h2>Реєстраційна форма</h2>
      
      <form style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <input
          type="text"
          name="name"
          placeholder="Ім'я"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="text"
          name="surname"
          placeholder="Прізвище"
          value={formData.surname}
          onChange={handleChange}
        />
        <input
          type="text"
          name="groupCode"
          placeholder="Код групи"
          value={formData.groupCode}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Електронна пошта"
          value={formData.email}
          onChange={handleChange}
        />
      </form>

      <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#f0f0f0', borderRadius: '8px' }}>
        <h3>Введені дані:</h3>
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          <li><strong>Ім'я:</strong> {formData.name}</li>
          <li><strong>Прізвище:</strong> {formData.surname}</li>
          <li><strong>Код групи:</strong> {formData.groupCode}</li>
          <li><strong>Email:</strong> {formData.email}</li>
        </ul>
      </div>
    </div>
  );
}

export default UserForm;