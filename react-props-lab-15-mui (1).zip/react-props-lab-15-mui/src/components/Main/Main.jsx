import React from 'react';
import Card from '../Card/Card';
import './Main.css';

const Main = ({ cards }) => {
  return (
    <div className="card-list">
      {/* Використовуємо .map() для рендеру масиву об'єктів у компоненти Card */}
      {cards.map((card) => (
        <Card 
          key={card.id} 
          title={card.title} 
          description={card.description} 
          image={card.image} 
        />
      ))}
    </div>
  );
};

export default Main;