import React from 'react';
import ProfileCard from './components/ProfileCard'; // Імпортуємо нашу нову MUI-картку
import { Container, Grid, Typography, CssBaseline, Box } from '@mui/material';

const cardsData = [
  { 
    id: 1, 
    title: "Лісова прогулянка", 
    description: "Затишний лісовий пейзаж для відпочинку на природі.", 
    image: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=400&h=300&fit=crop" 
  },
  { 
    id: 2, 
    title: "Місто вночі", 
    description: "Нічне місто з яскравими вогнями та неймовірною атмосферою.", 
    image: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400&h=300&fit=crop" 
  },
  { 
    id: 3, 
    title: "Гірський пейзаж", 
    description: "Краєвид величних гір під яскравим сонячним небом.", 
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&h=300&fit=crop" 
  },
  { 
    id: 4, 
    title: "Морський берег", 
    description: "Спокійний пляж із чистою водою та м'яким піском.", 
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&h=300&fit=crop" 
  },
  { 
    id: 5, 
    title: "Захід сонця", 
    description: "Романтичний захід сонця, що фарбує небо у дивовижні кольори.", 
    image: "https://images.unsplash.com/photo-1444090542259-0af8fa96557e?w=400&h=300&fit=crop" 
  }
];

function App() {
  return (
    <React.Fragment>
      {/* CssBaseline автоматично виправляє відступи браузера */}
      <CssBaseline />
      
      <Container maxWidth="lg">
        <Box sx={{ my: 4 }}>
          <Typography variant="h3" component="h1" align="center" gutterBottom fontWeight="bold">
            Галерея карток (MUI)
          </Typography>

          {/* Використовуємо Grid для створення адаптивної сітки */}
          <Grid container spacing={4} justifyContent="center">
            {cardsData.map((card) => (
              <Grid item key={card.id} xs={12} sm={6} md={4}>
                <ProfileCard 
                  title={card.title} 
                  description={card.description} 
                  image={card.image} 
                />
              </Grid>
            ))}
          </Grid>
        </Box>
      </Container>
    </React.Fragment>
  );
}

export default App;