import React, { useState, useEffect } from 'react';

const ColorBlock = () => {
  // 1. Застосування хука useState: ініціалізуємо початковий стан кольору (red)
  const [color, setColor] = useState('red');

  // 2. Використання хука useEffect: слідкуємо за зміною змінної 'color'
  useEffect(() => {
    // Цей код виконається при першому рендері та КОЖНОГО разу, коли зміниться 'color'
    console.log(`Поточний колір блока: ${color}`);
  }, [color]); // Масив залежностей містить 'color'

  // 3. Створення функції для зміни кольору
  const toggleColor = () => {
    // Перевіряємо поточний колір і чергуємо між червоним і синім
    setColor((prevColor) => (prevColor === 'red' ? 'blue' : 'red'));
  };

  // 4. Рендеринг блока та кнопки
  return (
    <div style={styles.container}>
      {/* Блок, який змінює свій фон в залежності від стану color */}
      <div 
        style={{ 
          ...styles.block, 
          backgroundColor: color 
        }} 
      ></div>
      
      {/* Кнопка для виклику функції зміни кольору */}
      <button style={styles.button} onClick={toggleColor}>
        Змінити колір
      </button>
    </div>
  );
};

// Прості стилі для кращого відображення
const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '50px',
  },
  block: {
    width: '200px',
    height: '200px',
    border: '2px solid #333',
    borderRadius: '10px',
    transition: 'background-color 0.3s ease', // Плавна зміна кольору
  },
  button: {
    marginTop: '20px',
    padding: '10px 20px',
    fontSize: '16px',
    cursor: 'pointer',
    borderRadius: '5px',
    border: '1px solid #ccc',
  }
};

export default ColorBlock;