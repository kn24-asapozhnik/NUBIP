import React from 'react';
import ColorBlock from './ColorBlock';

function App() {
  return (
    <div>
      <h1 style={{ textAlign: 'center', marginTop: '20px' }}>
        Лабораторна робота: useEffect
      </h1>
      {/* Рендеримо компонент ColorBlock */}
      <ColorBlock />
    </div>
  );
}

export default App;